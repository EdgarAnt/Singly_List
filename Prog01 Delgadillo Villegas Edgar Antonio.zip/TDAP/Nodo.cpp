#include "Nodo.h"

Nodo::Nodo()
{
	dato = "";
	sig = nullptr;
}

Nodo::~Nodo()
{

}
